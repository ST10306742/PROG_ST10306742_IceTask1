/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package icetask1_st10306742;

import javax.swing.JOptionPane;

/**
 *
 * @author shail
 */
//child class
public class Reptile extends Animal {
    private double bloodTemp;
    
    @Override
    public void input(){//overrode method for user input
        super.setIDTag(Integer.parseInt(JOptionPane.showInputDialog(null,"Enter reptile's ID tag.")));
        super.setSpecies(JOptionPane.showInputDialog(null,"Enter species of reptile."));
        bloodTemp=Double.parseDouble(JOptionPane.showInputDialog(null,"Enter blood tempreture of reptile."));//gets blood temp for reptiles
    }
    @Override
    public void output(){//overrode method for output
        JOptionPane.showMessageDialog(null, "Reptile\nID Tag: "+getIDTag()+"\nSpecies: "+
                                            getSpecies()+"\nBlood Tempreture: "+bloodTemp);
    }
}
