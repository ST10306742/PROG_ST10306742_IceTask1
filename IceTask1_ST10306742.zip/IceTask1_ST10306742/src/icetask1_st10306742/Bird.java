/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package icetask1_st10306742;

import javax.swing.JOptionPane;

/**
 *
 * @author shail
 */
//child class
public class Bird extends Animal{
    private int colour;//selection process
    /*
    1-grey
    2-white
    3-black
    */
    @Override
        public void input(){//overrode method for user input
            super.setIDTag(Integer.parseInt(JOptionPane.showInputDialog(null,"Enter bird's ID tag.")));
            super.setSpecies(JOptionPane.showInputDialog(null,"Enter species of bird."));   //calling methods from super/parent class
            boolean validColour=false;
            while(validColour==false){
            colour=Integer.parseInt(JOptionPane.showInputDialog(null,"Selecr the bird's colour:\n"+
                                                                "1-grey\n2-white\n3-black"));
                if (colour>0 && colour<4) {
                    validColour=true;
                }else {
                        JOptionPane.showMessageDialog(null, colour+" is not a valid option.");
                    }
            }
    }
    @Override
        public void output(){//overrode method for output
            if (colour==1) {
            JOptionPane.showMessageDialog(null, "Bird\nID Tag: "+getIDTag()+"\nSpecies: "+
                                            getSpecies()+"\nColour: Grey");
        } else {
                if (colour==2) {
                    JOptionPane.showMessageDialog(null, "Bird\nID Tag: "+getIDTag()+"\nSpecies: "+
                                            getSpecies()+"\nColour: White");
                } else {
                    if (colour==3) {
                        JOptionPane.showMessageDialog(null, "Bird\nID Tag: "+getIDTag()+"\nSpecies: "+
                                            getSpecies()+"\nColour: Black");
                    } 
                }
        }
        
    }
}
