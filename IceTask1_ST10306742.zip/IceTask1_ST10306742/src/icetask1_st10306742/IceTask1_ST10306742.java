/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package icetask1_st10306742;

/**
 *
 * @author shail
 */
//ST10306742
public class IceTask1_ST10306742 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bird brd = new Bird();              //instantiating objects 
        Reptile rept = new Reptile();
        
        brd.input();        //calling input & output methods from child classes
        rept.input();
        brd.output();
        rept.output();
    }
    
}
