/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package icetask1_st10306742;

import javax.swing.JOptionPane;

/**
 *
 * @author shail
 */
//parent class
public class Animal {
    private int IDTag;
    private String species;

    public int getIDTag() {
        return IDTag;
    }

    public void setIDTag(int IDTag) {                   //gets and sets for private var
        this.IDTag = IDTag;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
    public void input(){    //method for user input
        this.setIDTag(Integer.parseInt(JOptionPane.showInputDialog(null,"Enter animal's ID tag.")));
        this.setSpecies(JOptionPane.showInputDialog(null,"Enter species of animal."));
    }
    public void output(){   //method for output 
        JOptionPane.showMessageDialog(null, "Animal\nID Tag: "+getIDTag()+"\nSpecies: "+
                                            getSpecies());
    }
}
